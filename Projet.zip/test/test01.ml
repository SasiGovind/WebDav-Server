1 + 2;;
(* 1 + 0.5;; *)
let a = 1 + 2;;
true;;
false;;
0.5;;
0;;
0.0;;
'a';;
'b';;
"hello";;
1 + 2;;
1.7 +. 3.5;;
(* 1 +. 3.5;; *)
(* 1 + 3.5;; *)
int_of_float 3.5;;
float_of_int 3;;
(+) 1 2;;
( + ) 1 2;;
let x = 1;;
1;;
fun x -> 3 * x * x;;
let f = fun x -> 3 * x * x;;
let g= fun toto -> 3 * toto * toto;;
( + ) 1 2;;
( + ) 1;;
( + );;
((+) 1) 2;;
(* ((+) 1) (+);; *)
let norme2 = fun x -> fun y -> x * x + y * y;;
f 5;;
g;;
g 5;;
not;;
(&&);;
(||);;
1 = 2;;
(=);;
(<);;
f = g;;
"aaa" < "bbb";;
"bbb" < "aaa";;
"aab" < "aac";;
"zab" < "aac";;
"zab" < "Zab";;
"zab" > "Zab";;
";ab" > "Zab";;

